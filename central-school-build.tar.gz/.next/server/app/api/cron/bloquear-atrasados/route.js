var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cron/bloquear-atrasados/route.js")
R.c("server/chunks/[root-of-the-server]__0w32s8_._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_cron_bloquear-atrasados_route_actions_0l05v2l.js")
R.m(14644)
module.exports=R.m(14644).exports
