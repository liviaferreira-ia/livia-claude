var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/professor/acesso/route.js")
R.c("server/chunks/[root-of-the-server]__0k0ljl4._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_next-internal_server_app_api_professor_acesso_route_actions_1m3bkef.js")
R.m(59519)
module.exports=R.m(59519).exports
