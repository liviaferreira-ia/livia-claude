var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/professor/financeiro/sincronizar/route.js")
R.c("server/chunks/[root-of-the-server]__1nht7hg._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/1oeh_server_app_api_professor_financeiro_sincronizar_route_actions_0z87e4n.js")
R.m(33396)
module.exports=R.m(33396).exports
