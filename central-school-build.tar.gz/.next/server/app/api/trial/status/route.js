var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/trial/status/route.js")
R.c("server/chunks/[root-of-the-server]__079hpcu._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_trial_status_route_actions_1_014cj.js")
R.m(27341)
module.exports=R.m(27341).exports
