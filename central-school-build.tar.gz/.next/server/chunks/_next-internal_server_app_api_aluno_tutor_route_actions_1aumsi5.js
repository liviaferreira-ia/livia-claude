module.exports=[61060,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_aluno_tutor_route_actions_1aumsi5.js.map