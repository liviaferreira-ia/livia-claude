module.exports=[18769,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_professor_acesso_route_actions_1m3bkef.js.map