module.exports=[54744,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_professor_alunos_%5Bid%5D_route_actions_1bpabgl.js.map