module.exports=[76989,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_professor_convidar-aluno_route_actions_105np7x.js.map