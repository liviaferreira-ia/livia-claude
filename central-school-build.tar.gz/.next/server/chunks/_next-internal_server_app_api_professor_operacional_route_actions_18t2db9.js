module.exports=[92357,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_professor_operacional_route_actions_18t2db9.js.map