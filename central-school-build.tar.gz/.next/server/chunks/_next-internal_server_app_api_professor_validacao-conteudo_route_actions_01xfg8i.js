module.exports=[54373,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_professor_validacao-conteudo_route_actions_01xfg8i.js.map