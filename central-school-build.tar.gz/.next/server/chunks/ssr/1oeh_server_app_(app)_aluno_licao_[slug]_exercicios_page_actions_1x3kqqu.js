module.exports=[83254,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28app%29_aluno_licao_%5Bslug%5D_exercicios_page_actions_1x3kqqu.js.map