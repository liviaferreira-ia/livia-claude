module.exports=[14861,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28app%29_aluno_licao_%5Bslug%5D_expressoes_page_actions_1tap0qy.js.map