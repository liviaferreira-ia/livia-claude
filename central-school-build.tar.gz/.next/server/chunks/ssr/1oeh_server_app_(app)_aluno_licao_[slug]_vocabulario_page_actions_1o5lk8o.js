module.exports=[50553,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28app%29_aluno_licao_%5Bslug%5D_vocabulario_page_actions_1o5lk8o.js.map