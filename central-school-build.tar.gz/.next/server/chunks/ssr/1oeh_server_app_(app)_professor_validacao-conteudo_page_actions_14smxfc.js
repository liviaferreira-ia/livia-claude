module.exports=[6410,(a,b,c)=>{}];

//# sourceMappingURL=1oeh_server_app_%28app%29_professor_validacao-conteudo_page_actions_14smxfc.js.map