module.exports=[52659,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_conta_page_actions_0yb8-vg.js.map