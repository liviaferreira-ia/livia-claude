module.exports=[86164,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_curso_page_actions_0zs5vt8.js.map