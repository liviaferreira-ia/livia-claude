module.exports=[27718,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_licao_%5Bslug%5D_intro_page_actions_1_ddyb0.js.map