module.exports=[82980,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_licao_%5Bslug%5D_page_actions_0y28b_5.js.map