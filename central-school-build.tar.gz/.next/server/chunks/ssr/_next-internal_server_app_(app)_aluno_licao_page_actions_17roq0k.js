module.exports=[17e3,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_licao_page_actions_17roq0k.js.map