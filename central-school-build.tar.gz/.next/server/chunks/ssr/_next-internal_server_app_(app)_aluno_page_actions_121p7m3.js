module.exports=[59800,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_page_actions_121p7m3.js.map