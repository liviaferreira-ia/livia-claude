module.exports=[5162,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_palavras_page_actions_16ort87.js.map