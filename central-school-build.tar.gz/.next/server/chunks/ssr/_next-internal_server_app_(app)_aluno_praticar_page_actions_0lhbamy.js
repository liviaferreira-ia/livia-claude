module.exports=[2762,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_praticar_page_actions_0lhbamy.js.map