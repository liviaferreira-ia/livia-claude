module.exports=[21619,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_progresso_page_actions_21asd0r.js.map