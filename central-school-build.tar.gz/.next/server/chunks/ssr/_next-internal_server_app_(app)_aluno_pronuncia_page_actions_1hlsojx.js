module.exports=[87873,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_pronuncia_page_actions_1hlsojx.js.map