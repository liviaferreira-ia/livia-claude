module.exports=[38233,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_revisao_page_actions_1w1qje6.js.map