module.exports=[5980,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_roleplay_page_actions_0nwton5.js.map