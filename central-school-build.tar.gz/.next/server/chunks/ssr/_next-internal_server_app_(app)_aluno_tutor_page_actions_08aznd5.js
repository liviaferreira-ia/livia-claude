module.exports=[74508,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_tutor_page_actions_08aznd5.js.map