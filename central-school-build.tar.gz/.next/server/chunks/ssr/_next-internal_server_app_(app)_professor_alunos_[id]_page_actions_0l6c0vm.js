module.exports=[18252,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_professor_alunos_%5Bid%5D_page_actions_0l6c0vm.js.map