module.exports=[23626,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_professor_alunos_page_actions_1i_4-3q.js.map