module.exports=[84594,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_professor_financeiro_page_actions_1057_t3.js.map