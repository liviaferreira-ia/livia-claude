module.exports=[84975,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_professor_operacional_page_actions_0-m6hz6.js.map