module.exports=[24331,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_professor_page_actions_165xgl7.js.map