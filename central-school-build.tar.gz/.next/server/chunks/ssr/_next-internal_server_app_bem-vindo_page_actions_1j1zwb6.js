module.exports=[93209,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bem-vindo_page_actions_1j1zwb6.js.map