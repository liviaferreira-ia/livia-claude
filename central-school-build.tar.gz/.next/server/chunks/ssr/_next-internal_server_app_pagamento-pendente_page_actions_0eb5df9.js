module.exports=[94986,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_pagamento-pendente_page_actions_0eb5df9.js.map