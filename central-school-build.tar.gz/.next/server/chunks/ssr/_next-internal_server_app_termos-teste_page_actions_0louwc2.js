module.exports=[72096,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_termos-teste_page_actions_0louwc2.js.map