module.exports=[51442,a=>{"use strict";var b=a.i(87924),c=a.i(50944),d=a.i(48740);a.s(["ConcluirEtapa",0,function({slug:a,id:e,label:f="Concluir etapa →"}){let g=(0,c.useRouter)();return(0,b.jsx)("button",{className:"btn primary",onClick:()=>{(0,d.markSectionDone)(a,e),g.push(`/aluno/licao/${a}`)},children:f})}])}];

//# sourceMappingURL=src_components_ConcluirEtapa_tsx_0fshy9f._.js.map