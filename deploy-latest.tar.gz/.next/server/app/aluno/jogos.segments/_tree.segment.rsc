:HL["/_next/static/chunks/2-juj6dp-02ps.css","style"]
:HL["/_next/static/chunks/19_98v-4l62lb.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"(app)","param":null,"prefetchHints":4192,"slots":{"children":{"name":"aluno","param":null,"prefetchHints":4192,"slots":{"children":{"name":"jogos","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}}}}}},"staleTime":300,"buildId":"nemiNUo-AkE4OyOWZiR4q"}
