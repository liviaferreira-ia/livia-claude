var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/aluno/tutor/route.js")
R.c("server/chunks/[root-of-the-server]__1tzwvyb._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_09ncxqz._.js")
R.c("server/chunks/_next-internal_server_app_api_aluno_tutor_route_actions_1aumsi5.js")
R.m(5020)
module.exports=R.m(5020).exports
