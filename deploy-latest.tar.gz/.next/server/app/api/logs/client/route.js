var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/logs/client/route.js")
R.c("server/chunks/[root-of-the-server]__19h5-r7._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_logs_client_route_actions_046dwbw.js")
R.m(35677)
module.exports=R.m(35677).exports
