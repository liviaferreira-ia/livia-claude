var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/professor/alunos/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0gh-b79._.js")
R.c("server/chunks/_1mtlmra._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/_next-internal_server_app_api_professor_alunos_[id]_route_actions_1bpabgl.js")
R.m(18649)
module.exports=R.m(18649).exports
