var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/professor/convidar-aluno/route.js")
R.c("server/chunks/[root-of-the-server]__0gh-b79._.js")
R.c("server/chunks/_0_dx2a0._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/_next-internal_server_app_api_professor_convidar-aluno_route_actions_105np7x.js")
R.m(54334)
module.exports=R.m(54334).exports
