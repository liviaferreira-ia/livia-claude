var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/professor/financeiro/pre-cadastros/route.js")
R.c("server/chunks/[root-of-the-server]__05if070._.js")
R.c("server/chunks/_0pbl6iz._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/1oeh_server_app_api_professor_financeiro_pre-cadastros_route_actions_12l_8pg.js")
R.m(51007)
module.exports=R.m(51007).exports
