var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/professor/operacional/route.js")
R.c("server/chunks/[root-of-the-server]__0nqr7ej._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_professor_operacional_route_actions_18t2db9.js")
R.m(26017)
module.exports=R.m(26017).exports
