var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/professor/validacao-conteudo/route.js")
R.c("server/chunks/[root-of-the-server]__1tzwvyb._.js")
R.c("server/chunks/_18tzx_4._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/_next-internal_server_app_api_professor_validacao-conteudo_route_actions_01xfg8i.js")
R.m(8115)
module.exports=R.m(8115).exports
