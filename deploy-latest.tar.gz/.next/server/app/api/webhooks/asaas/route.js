var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhooks/asaas/route.js")
R.c("server/chunks/[root-of-the-server]__0pv3ulh._.js")
R.c("server/chunks/_1ud0s8i._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_webhooks_asaas_route_actions_0fvefny.js")
R.m(97868)
module.exports=R.m(97868).exports
