var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/confirm/route.js")
R.c("server/chunks/[root-of-the-server]__1cr3cls._.js")
R.c("server/chunks/_17qm_ju._.js")
R.c("server/chunks/node_modules_@supabase_supabase-js_dist_index_mjs_0u-n9p7._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_auth_confirm_route_actions_0ig3y12.js")
R.m(57487)
module.exports=R.m(57487).exports
