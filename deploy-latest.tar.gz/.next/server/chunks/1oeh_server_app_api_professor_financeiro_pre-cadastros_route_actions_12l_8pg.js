module.exports=[75861,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_professor_financeiro_pre-cadastros_route_actions_12l_8pg.js.map