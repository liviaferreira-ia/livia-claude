module.exports=[55900,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28app%29_aluno_jogos_page_actions_14zjr_b.js.map