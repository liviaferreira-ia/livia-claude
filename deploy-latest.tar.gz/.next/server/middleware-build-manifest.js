globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/nemiNUo-AkE4OyOWZiR4q/_buildManifest.js",
    "static/nemiNUo-AkE4OyOWZiR4q/_ssgManifest.js",
    "static/nemiNUo-AkE4OyOWZiR4q/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/4561u0v7ysn3r.js",
    "static/chunks/2_kj6kxzawxym.js",
    "static/chunks/turbopack-01lkw-bcqpxrk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
